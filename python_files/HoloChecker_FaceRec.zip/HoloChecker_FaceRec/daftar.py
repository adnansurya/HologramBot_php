from genericpath import isdir
import cv2
import numpy as np
import face_recognition
import nameSplitter as ns
import time
import dbManager
import os

namaFolder = "Foto"

namaFoto = str(input("Masukkan Nama Panggilan: "))
namaFoto += ".jpg"


objVideo = cv2. VideoCapture(0)
if not objVideo.isOpened():
    print('Kamera tak dapat diakses')
    exit()

tombolQditekan = False
adaFoto = False
while (tombolQditekan == False):
    ret, kerangka = objVideo.read()
    
    if ret == True:
        cv2.imshow('Frame',kerangka)
        # abuAbu = cv2.cvtColor(kerangka,cv2.COLOR_BGR2GRAY)
        # dafWajah = face_cascade.detectMultiScale(abuAbu, scaleFactor = 1.3, minNeighbors = 2)

        # for(x, y, w, h) in dafWajah:
        #     cv2.rectangle(kerangka,(x,y),(x + w, y + h), (255, 0, 0), 2)
        

        faces_cur_frame = face_recognition.face_locations(kerangka)
        
        print(str(faces_cur_frame))

        if len(faces_cur_frame) > 0:
            print("Ada Orang")
            if not os.path.isdir(namaFolder):
                os.mkdir(namaFolder)
            cv2.imwrite(namaFolder+"/"+namaFoto, kerangka)
            adaFoto = True
            break

        if cv2.waitKey(1) & 0xFF == ord('q'):
            tombolQditekan = True
            break
    else:
        break

objVideo.release()
cv2.destroyAllWindows()
if(adaFoto):
    idTelegram = str(input("Masukkan Id Telegram :"))
    idKtp = str(input("Masukkan Id KTP: "))
    namaLengkap = str(input("Masukkan Nama Lengkap: "))
    firstName = str(input("First Name: ")) #ns.awalNama(namaLengkap)
    lastName =  str(input("Last Name: "))#ns.akhirNama(namaLengkap)
    username = str(input("Masukkan username : "))
    timeStamp = int(time.time())
    dbManager.newUser(idTelegram, idKtp, firstName, lastName,username, namaFoto, timeStamp, 1)






    